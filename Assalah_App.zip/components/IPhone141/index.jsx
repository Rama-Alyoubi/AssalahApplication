import React from "react";
import { Link } from "react-router-dom";
import "./IPhone141.css";

function IPhone141(props) {
  const { rectangle18034, x1062871271575949852222Gettyimages1 } = props;

  return (
    <div className="container-center-horizontal">
      <form
        className="iphone-14-1 screen"
        onclick="window.open('javascript:SubmitForm(%27form2%27)', '_self');"
        name="form2"
        action="form2"
        method="post"
      >
        <div className="overlap-group-1">
          <Link to="/iphone-14-2">
            <img className="rectangle-18034-1" src={rectangle18034} alt="Rectangle 18034" />
          </Link>
          <img
            className="x106287127-1575949852"
            src={x1062871271575949852222Gettyimages1}
            alt="106287127-1575949852222gettyimages-149814787-02 1"
          />
        </div>
      </form>
    </div>
  );
}

export default IPhone141;
