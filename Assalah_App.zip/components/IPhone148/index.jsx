import React from "react";
import Group2282 from "../Group2282";
import Group2233 from "../Group2233";
import Group2283 from "../Group2283";
import Group2290 from "../Group2290";
import "./IPhone148.css";

function IPhone148(props) {
  const {
    overlapGroup1,
    title,
    overlapGroup,
    artifacts,
    artifactName,
    description,
    inputType1,
    inputPlaceholder1,
    inputType2,
    inputPlaceholder2,
    group2196,
    group2283Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <form className="iphone-14-8 screen" name="form1" action="form1" method="post">
        <div className="overlap-group3">
          <div className="rectangle-18034"></div>
          <div className="overlap-group1" style={{ backgroundImage: `url(${overlapGroup1})` }}>
            <h1 className="title mulish-bold-stonewall-32px">{title}</h1>
            <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup})` }}>
              <div className="artifacts mulish-bold-stonewall-24px">{artifacts}</div>
            </div>
          </div>
          <div className="group-2239">
            <img className="shape-with-text" src="/img/shape-with-text.svg" alt="Shape with text" />
            <img className="subtract" src="/img/subtract.svg" alt="Subtract" />
          </div>
          <div className="group-2240 inter-semi-bold-sand-dune-20px">
            <div className="group-2240-item">{artifactName}</div>
            <div className="group-2237"></div>
            <div className="group-2240-item">{description}</div>
            <div className="group-2238"></div>
          </div>
          <textarea
            className="x poppins-normal-silver-12px"
            name="................................................................................................................."
            placeholder={inputPlaceholder1}
            type={inputType1}
            required
          ></textarea>
          <textarea
            className="x-1 poppins-normal-silver-12px"
            name="................................................................................................................. ................................................................................................................. ................................................................................................................."
            placeholder={inputPlaceholder2}
            type={inputType2}
            required
          ></textarea>
          <div className="overlap-group2">
            <div className="group-2230"></div>
            <Group2282 />
            <a href="javascript:SubmitForm('form1')">
              <div className="group-2284">
                <img className="group-2196" src={group2196} alt="Group 2196" />
              </div>
            </a>
            <Group2233 />
            <Group2283 src={group2283Props.src} />
            <img className="ellipse-21" src="/img/ellipse-21.svg" alt="Ellipse 21" />
            <Group2290 />
          </div>
        </div>
      </form>
    </div>
  );
}

export default IPhone148;
