import React from "react";
import "./Rectangle18021.css";

function Rectangle18021() {
  return <div className="rectangle-18021"></div>;
}

export default Rectangle18021;
