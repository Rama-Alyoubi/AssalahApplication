import React from "react";
import Group2282 from "../Group2282";
import Group2233 from "../Group2233";
import Group2283 from "../Group2283";
import Group2290 from "../Group2290";
import "./IPhone145.css";

function IPhone145(props) {
  const { overlapGroup1, title, overlapGroup, artifacts, scanAnyArtifactsAroundYou, group2196, group2283Props } = props;

  return (
    <div className="container-center-horizontal">
      <form className="iphone-14-5 screen" name="form8" action="form8" method="post">
        <div className="overlap-group3-4">
          <div className="rectangle-18034-5"></div>
          <div className="group-2266">
            <img className="subtract-1" src="/img/subtract-2.svg" alt="Subtract" />
            <a href="javascript:SubmitForm('form8')">
              <div className="group-298">
                <div className="ellipse-container-1">
                  <div className="ellipse-6-1"></div>
                  <div className="ellipse-7-1"></div>
                </div>
              </div>
            </a>
          </div>
          <div className="overlap-group1-7" style={{ backgroundImage: `url(${overlapGroup1})` }}>
            <h1 className="title-3 mulish-bold-stonewall-32px">{title}</h1>
            <div className="overlap-group-7" style={{ backgroundImage: `url(${overlapGroup})` }}>
              <div className="artifacts-2 mulish-bold-stonewall-24px">{artifacts}</div>
            </div>
          </div>
          <p className="scan-any-artifacts-around-you-1 inter-semi-bold-stonewall-18px">{scanAnyArtifactsAroundYou}</p>
          <div className="overlap-group2-5">
            <div className="group-2230-2"></div>
            <Group2282 />
            <a href="javascript:SubmitForm('form8')">
              <div className="group-2284-2">
                <img className="group-2196-2" src={group2196} alt="Group 2196" />
              </div>
            </a>
            <Group2233 />
            <Group2283 src={group2283Props.src} />
            <img className="ellipse-21-2" src="/img/ellipse-21.svg" alt="Ellipse 21" />
            <Group2290 />
          </div>
        </div>
      </form>
    </div>
  );
}

export default IPhone145;
