import React from "react";
import "./Group2241.css";

function Group2241() {
  return (
    <div className="group-2241-3">
      <img className="group-3" src="/img/group-3.svg" alt="Group" />
    </div>
  );
}

export default Group2241;
