import React from "react";
import "./Group2233.css";

function Group2233() {
  return (
    <div className="group-2233">
      <div className="group-2241">
        <img className="group" src="/img/group@2x.png" alt="Group" />
      </div>
    </div>
  );
}

export default Group2233;
