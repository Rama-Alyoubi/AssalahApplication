import React from "react";
import "./Group2282.css";

function Group2282(props) {
  const { className } = props;

  return (
    <div className={`group-2282 ${className || ""}`}>
      <img className="vector" src="/img/vector.svg" alt="Vector" />
    </div>
  );
}

export default Group2282;
