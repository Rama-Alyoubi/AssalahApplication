import React from "react";
import Rectangle18021 from "../Rectangle18021";
import Group2282 from "../Group2282";
import Group2283 from "../Group2283";
import Group2241 from "../Group2241";
import "./IPhone142.css";

function IPhone142(props) {
  const {
    overlapGroup11,
    title,
    overlapGroup,
    explore,
    maskGroup1,
    diriyah,
    riyadhProvince,
    vector2,
    text1,
    search,
    sights,
    tour,
    adventure,
    maskGroup2,
    discoverAlula,
    surname,
    text2,
    tourGuides,
    seeAll,
    maskGroup3,
    name1,
    maskGroup4,
    lamaA,
    maskGroup5,
    name2,
    letsMakeAiGenera,
    inputType,
    inputPlaceholder,
    group2282Props,
    group2283Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <form className="iphone-14-2 screen" name="form6" action="form6" method="post">
        <div className="overlap-group11">
          <img className="rectangle-18034-3" src="/img/rectangle-18034-4.svg" alt="Rectangle 18034" />
          <div className="overlap-group10">
            <div className="i-phone-14-1">
              <div className="overlap-group3-2">
                <img className="rectangle-18034-4" src="/img/rectangle-18034-5.svg" alt="Rectangle 18034" />
                <div className="overlap-group1-2" style={{ backgroundImage: `url(${overlapGroup11})` }}>
                  <h1 className="title-2 mulish-bold-stonewall-32px">{title}</h1>
                  <div className="overlap-group-4" style={{ backgroundImage: `url(${overlapGroup})` }}>
                    <div className="explore mulish-bold-stonewall-24px">{explore}</div>
                  </div>
                </div>
                <div className="overlap-group2-3">
                  <div className="rectangle-18033"></div>
                  <img className="mask-group-1" src={maskGroup1} alt="Mask group" />
                  <div className="group-29">
                    <img className="vector-4" src="/img/vector-22@2x.png" alt="Vector" />
                    <div className="ellipse-2"></div>
                  </div>
                  <div className="group-32">
                    <div className="riya-container">
                      <div className="diriyah poppins-semi-bold-shuttle-gray-14px">{diriyah}</div>
                      <div className="riyadh-province poppins-light-shuttle-gray-10px">{riyadhProvince}</div>
                    </div>
                    <div className="group-30">
                      <img className="vector-5" src={vector2} alt="Vector" />
                      <div className="overlap-group1-3">
                        <div className="text poppins-normal-white-10px">{text1}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="frame-1">
              <div className="overlap-group3-3">
                <img className="group-1-1" src="/img/group-1-2.svg" alt="Group 1" />
                <div className="search poppins-normal-silver-12px">{search}</div>
                <img className="line-9" src="/img/line-9-2.svg" alt="Line 9" />
                <img className="group-285" src="/img/group-285-2.svg" alt="Group 285" />
              </div>
              <div className="overlap-group-container">
                <div className="overlap-group7">
                  <div className="sights">{sights}</div>
                </div>
                <div className="overlap-group9">
                  <div className="tour poppins-normal-shuttle-gray-12px">{tour}</div>
                </div>
                <div className="overlap-group8">
                  <div className="adventure poppins-normal-shuttle-gray-12px">{adventure}</div>
                </div>
              </div>
              <a href="javascript:SubmitForm('form6')" className="align-self-flex-start">
                <div className="group-33">
                  <div className="overlap-group6">
                    <div className="rectangle-18033"></div>
                    <img className="mask-group-2" src={maskGroup2} alt="Mask group" />
                    <div className="group-29-1">
                      <img className="vector-6" src="/img/vector-30.svg" alt="Vector" />
                    </div>
                    <div className="group-32-1">
                      <div className="overlap-group-5">
                        <div className="discover-al-ula poppins-semi-bold-shuttle-gray-14px">{discoverAlula}</div>
                        <div className="surname poppins-light-shuttle-gray-10px">{surname}</div>
                      </div>
                      <div className="overlap-group1-4">
                        <img className="vector-7" src="/img/vector-31.svg" alt="Vector" />
                        <div className="text poppins-normal-white-10px">{text2}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
              <div className="group-287">
                <div className="flex-row">
                  <div className="tour-guides mulish-bold-stonewall-18px">{tourGuides}</div>
                  <div className="see-all">{seeAll}</div>
                </div>
                <div className="group-286">
                  <a href="javascript:SubmitForm('form6')">
                    <div className="group-7">
                      <div className="overlap-group-6">
                        <Rectangle18021 />
                        <img className="mask-group-3" src={maskGroup3} alt="Mask group" />
                        <img className="ellipse-3" src="/img/ellipse-3-6.svg" alt="Ellipse 3" />
                        <div className="name poppins-semi-bold-sonic-silver-18px">{name1}</div>
                        <img className="vector-8" src="/img/vector-24.svg" alt="Vector" />
                      </div>
                    </div>
                  </a>
                  <div className="group-8">
                    <div className="overlap-group1-5">
                      <img className="mask-group" src={maskGroup4} alt="Mask group" />
                      <img className="ellipse-3-1" src="/img/ellipse-3-6.svg" alt="Ellipse 3" />
                    </div>
                    <div className="lama-a poppins-semi-bold-sonic-silver-18px">{lamaA}</div>
                    <img className="vector-9" src="/img/vector-25.svg" alt="Vector" />
                  </div>
                  <div className="group-9">
                    <div className="overlap-group2-4">
                      <img className="mask-group" src={maskGroup5} alt="Mask group" />
                      <img className="ellipse-3-2" src="/img/ellipse-3-8.svg" alt="Ellipse 3" />
                    </div>
                    <div className="name-1 poppins-semi-bold-sonic-silver-18px">{name2}</div>
                    <img className="vector-10" src="/img/vector-26.svg" alt="Vector" />
                  </div>
                </div>
                <p className="lets-make-ai-genera mulish-bold-stonewall-18px">{letsMakeAiGenera}</p>
              </div>
              <div className="overlap-group4-1">
                <input
                  className="enter-the-city-youre-in"
                  name="enterthecityyourein"
                  placeholder={inputPlaceholder}
                  type={inputType}
                />
              </div>
              <div className="overlap-group5-1">
                <div className="rectangle-18038"></div>
                <div className="group-2270">
                  <div className="overlap-group1-6">
                    <div className="group-2278">
                      <div className="vector-container">
                        <img className="vector-11" src="/img/vector-28.svg" alt="Vector" />
                        <img className="vector-12" src="/img/vector-29.svg" alt="Vector" />
                      </div>
                    </div>
                  </div>
                  <Group2282 className={group2282Props.className} />
                  <Group2283 src={group2283Props.src} className={group2283Props.className} />
                  <a href="javascript:SubmitForm('form6')">
                    <div className="group-2281">
                      <img className="vuesaxboldscan-3" src="/img/vuesax-bold-scan-2.svg" alt="vuesax/bold/scan" />
                    </div>
                  </a>
                  <Group2241 />
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default IPhone142;
