import React from "react";
import "./Group2290.css";

function Group2290() {
  return (
    <div className="group-2290">
      <img className="vuesaxboldscan" src="/img/vuesax-bold-scan.svg" alt="vuesax/bold/scan" />
    </div>
  );
}

export default Group2290;
