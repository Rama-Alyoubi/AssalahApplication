import React from "react";
import Group2282 from "../Group2282";
import Group2233 from "../Group2233";
import Group2283 from "../Group2283";
import Group2290 from "../Group2290";
import "./IPhone147.css";

function IPhone147(props) {
  const {
    overlapGroup2,
    title,
    overlapGroup,
    artifacts,
    scanAnyArtifactsAroundYou,
    doYouWantToAddIt,
    close,
    add,
    unknownArtifact,
    group2196,
    group2283Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <form className="iphone-14-7 screen" name="form3" action="form3" method="post">
        <div className="overlap-group5">
          <div className="rectangle-18034-2"></div>
          <div className="group-container">
            <div className="group-2197">
              <div className="group-2195"></div>
            </div>
            <div className="ellipse-container">
              <div className="ellipse-6"></div>
              <div className="ellipse-7"></div>
            </div>
          </div>
          <div className="overlap-group2-1" style={{ backgroundImage: `url(${overlapGroup2})` }}>
            <h1 className="title-1 mulish-bold-stonewall-32px">{title}</h1>
            <div className="overlap-group-2" style={{ backgroundImage: `url(${overlapGroup})` }}>
              <div className="artifacts-1 mulish-bold-stonewall-24px">{artifacts}</div>
            </div>
          </div>
          <p className="scan-any-artifacts-around-you inter-semi-bold-stonewall-18px">{scanAnyArtifactsAroundYou}</p>
          <div className="overlap-group3-1">
            <div className="overlap-group2-2">
              <p className="do-you-want-to-add-it">{doYouWantToAddIt}</p>
              <div className="group-2218">
                <div className="overlap-group-3">
                  <div className="close inter-semi-bold-white-16px">{close}</div>
                </div>
                <div className="overlap-group1-1">
                  <div className="add inter-semi-bold-white-16px">{add}</div>
                </div>
              </div>
            </div>
            <div className="unknown-artifact">{unknownArtifact}</div>
          </div>
          <div className="overlap-group4">
            <div className="group-2230-1"></div>
            <Group2282 />
            <a href="javascript:SubmitForm('form3')">
              <div className="group-2284-1">
                <img className="group-2196-1" src={group2196} alt="Group 2196" />
              </div>
            </a>
            <Group2233 />
            <Group2283 src={group2283Props.src} />
            <img className="ellipse-21-1" src="/img/ellipse-21.svg" alt="Ellipse 21" />
            <Group2290 />
          </div>
        </div>
      </form>
    </div>
  );
}

export default IPhone147;
