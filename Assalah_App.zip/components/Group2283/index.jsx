import React from "react";
import "./Group2283.css";

function Group2283(props) {
  const { src, className } = props;

  return (
    <div className={`group-2283 ${className || ""}`}>
      <img className="group-36" src={src} alt="Group 36" />
    </div>
  );
}

export default Group2283;
